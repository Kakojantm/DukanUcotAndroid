package com.dukan.ucot;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.view.WindowManager;
import android.graphics.Color;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  getWindow().setStatusBarColor(Color.rgb(16,43,70));
  getWindow().setNavigationBarColor(Color.rgb(16,43,70));
  WebView web=new WebView(this);
  web.setBackgroundColor(Color.rgb(242,245,249));
  WebSettings settings=web.getSettings();
  settings.setJavaScriptEnabled(true);
  settings.setDomStorageEnabled(true);
  settings.setAllowFileAccess(true);
  settings.setAllowContentAccess(false);
  web.setWebViewClient(new WebViewClient());
  web.loadUrl("file:///android_asset/index.html");
  setContentView(web);
 }
 @Override public void onBackPressed(){super.onBackPressed();}
}
