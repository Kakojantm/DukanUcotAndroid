# Dükan Üçot Android uygulaması

Bu proje, Android Studio ile APK oluşturulabilen çevrimdışı bir Android uygulamasıdır.

## Özellikler
- SKLAD: ürün ID'si, ürün adı, alış maliyeti, başlangıç adedi, satış fiyatı, satılan/kalan adet
- SATYŞ: ürün seçimi, stok kontrolü, satış kaydı, satış geliri ve ürün maliyeti/kârı
- ÇYKDAJY: kira, elektrik vb. genel giderleri kaydetme
- HASABAT: yıl bazında satış, satılan ürün maliyeti, brüt kâr, giderler ve net kâr
- Telefon içinde yerel kayıt (WebView localStorage), internet gerekmez
- JSON yedek dışa/içe aktarma

## APK oluşturma
1. Android Studio'yu bilgisayara kurun.
2. Bu klasörü Android Studio'da **Open** ile açın.
3. Gradle senkronizasyonu tamamlanınca **Build > Build APK(s)** seçin.
4. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` yolunda oluşur.

Not: Kaynak proje bu paket içindedir; bu çalışma ortamında Android SDK/Gradle bulunmadığı için burada derlenmiş APK üretilemedi.
