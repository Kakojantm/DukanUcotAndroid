# Dükan Üçot — Android APK projesi

## Uygulama
- SKLAD: harytlar, ID, alış bahasy, başlangyç sany, satuş bahasy
- SATYŞ: satuş girizmek, stok barlagy, awtomatik galan sany hasaplamak
- ÇYKDAJY: umumy çykdajylar
- HASABAT: ýyl boýunça satuş, öz baha, brüt peýda, çykdajy we arassa peýda
- Maglumatlar telefonda ýerli saklanýar; internet gerek däl.
- JSON ätiýaç nusgasyny eksport/import etmek bolýar.

## APK almak üçin aňsat usul (GitHub Actions)
Bu ZIP-i kompýuterde açyp, içindäki ähli faýllary täze GitHub repository-ä ýükläň. Soň:
1. GitHub repository-de **Actions** bölümine giriň.
2. **Build Android APK** workflow-y saýlaň.
3. **Run workflow** basyň.
4. Ýaşyl gutarandan soň şol işiň sahypasynyň aşagyndaky **Artifacts** bölüminden `Dukan-Ucot-APK` faýlyny ýükläň.
5. ZIP artifact-i açyň; içindäki `app-debug.apk`-y Android telefona geçirip guruň. Android sorasa, şol çeşmeden programma gurmaga rugsat beriň.

Workflow `.github/workflows/build-apk.yml` içinde bar. GitHub-yň Actions aýratynlygy repository üçin açyk bolmaly.

## Kompýuterde Android Studio bilen
`File > Open` arkaly taslama bukjasyny açyň, Gradle sync tamamlanandan soň `Build > Build APK(s)` saýlaň.

## Maglumatlaryň möhüm belligi
Maglumatlar bu telefonda WebView localStorage arkaly saklanýar. Programmany pozmak ýa-da programma maglumatlaryny arassalamak maglumatlary pozup biler; yzygiderli JSON backup alyň.

## Hasaplama düzgüni
Arassa peýda = satuş girdejisi − satuşa degişli haryt öz bahasy − umumy çykdajylar.
