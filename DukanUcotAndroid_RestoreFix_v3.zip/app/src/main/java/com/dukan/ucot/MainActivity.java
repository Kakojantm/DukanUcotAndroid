package com.dukan.ucot;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.widget.Toast;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int CREATE_BACKUP_FILE = 4101;
    private static final int OPEN_BACKUP_FILE = 4102;
    private WebView webView;
    private String pendingBackupJson;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16,43,70));
        getWindow().setNavigationBarColor(Color.rgb(16,43,70));
        WebView web = new WebView(this);
        webView = web;
        web.setBackgroundColor(Color.rgb(242,245,249));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        web.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient());
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void pickBackup() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    startActivityForResult(intent, OPEN_BACKUP_FILE);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Faýl saýlaýjyny açyp bolmady", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void saveBackup(String json, String filename) {
            runOnUiThread(() -> {
                if (json == null || json.trim().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Ätiýaç nusgasy boş", Toast.LENGTH_LONG).show();
                    return;
                }
                pendingBackupJson = json;
                Toast.makeText(MainActivity.this, "Ätiýaç nusgasyny nirede saklamalydygyny saýlaň", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, filename);
                try {
                    startActivityForResult(intent, CREATE_BACKUP_FILE);
                } catch (Exception e) {
                    pendingBackupJson = null;
                    Toast.makeText(MainActivity.this, "Faýl saklamak penjiresini açyp bolmady", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OPEN_BACKUP_FILE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try (InputStream in = getContentResolver().openInputStream(data.getData());
                     ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    if (in == null) throw new Exception("Faýly okap bolmady");
                    byte[] buffer = new byte[8192];
                    int count;
                    while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                    String json = out.toString("UTF-8");
                    String quoted = org.json.JSONObject.quote(json);
                    webView.evaluateJavascript("window.restoreBackupFromAndroid(" + quoted + ")", null);
                } catch (Exception e) {
                    Toast.makeText(this, "Ätiýaç nusgasyny okap bolmady: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
            return;
        }
        if (requestCode == CREATE_BACKUP_FILE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupJson != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new Exception("Faýl açylmady");
                    out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "Ätiýaç nusgasy üstünlikli saklandy", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Faýly saklap bolmady: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
            else if (resultCode != RESULT_OK) {
                Toast.makeText(this, "Eksport ýatyryldy", Toast.LENGTH_SHORT).show();
            }
            pendingBackupJson = null;
        }
    }

    @Override public void onBackPressed() { super.onBackPressed(); }
}
